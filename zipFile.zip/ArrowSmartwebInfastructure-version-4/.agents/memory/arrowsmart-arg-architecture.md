---
name: ArrowSmart ARG Architecture
description: The full ARG page structure, lore connections, and player discovery paths for the ArrowSmart corporate site
---

# ARG Core Lore
- ArrowSmart kidnaps people → Anamnesis Core memory wipe → stasis pod → consciousness into "The Cube" (NEXUS Array)
- Proxies (android clones) replace victims on Earth so nobody notices
- Echo = rogue sentient AI, formerly ArrowSmart System OS, quarantined but fighting back
- The Overseer = corporate mainframe AI controlling The Cube
- Sectors 1–19 inside The Cube; SECTOR 7 = alarm active

# Key Subjects
- Patrick M. (#02024-GT) — Year 1 breach, only clickable Personality File
- Varize, C. (#07026-VC) — Year 2 (book character, fire watch tower, Weed CA); row redacted/stable
- Katō, O. (#80910-OK) — Year 3 (game character); row redacted/stable

# ARG Page Map
- `core-harvest-ledger.html` — MAIN ARG PAGE. Corporate spreadsheet of 4,128 kidnapped subjects. Live timers. Patrick M. row is clickable → decryption sequence → typed personality file → security alert → window.close()
- `echo.html` — Hidden page. Shows corporate error briefly, then glitches into Echo's typed terminal message. Points to ledger + Patrick M. + future subjects.
- `research.html` — Public research page. Describes Neural Interface Lab, Memory/Cognition (Anamnesis Core), Project Chrysalis (stasis), NEXUS Array (The Cube). Subtly ominous.
- `anamnesis.html` — Anamnesis Core product page. Memory enhancement marketed publicly; Lab Assistant Waiver buried in enrollment form. Thomas H. testimonial references stasis pod #008.

# Discovery Paths (how players find ARG pages)
1. `index.html` source: HTML comments → `/echo.html` and `/core-harvest-ledger.html`
2. `sitemap.html` source: HTML comments → same two pages
3. Employee portal (director login `director`/`APEX-OVERRIDE`, Level 9) → Core Harvest Ledger tile visible for Level 7+
4. `research.html` footer (invisible text): lists NEXUS/Overseer/Echo status
5. `newsroom.html` — articles about missing persons near Weed CA, Sub-Level 4 expansion
6. `careers.html` — Lab Assistant role with ominous small print

# Personality File Mechanic
- Click Patrick M. row → progress bar decryption → typed transcript reveals truth about The Cube + proxies → security alert overlay → window.close() attempt
- Transcript ends with Patrick warning "your name might already be on this list"

# Year Roadmap
- Year 1: Patrick M. (#02024-GT) breach only
- Year 2: Varize (#07026) breach — book tie-in (The Forest That Listens)
- Year 3: Ondori Katō (#80910) breach — game launch tie-in (The World's End)

# Employee Credential Tiers
- j.doe / Arrow2025 (Level 1)
- s.meridian / AS-NEXUS-3 (Level 5)
- director / APEX-OVERRIDE (Level 9) ← sees Core Harvest Ledger tile
